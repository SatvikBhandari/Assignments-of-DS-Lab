// question 4(d) (sort string in alphabetically order)

#include<iostream>

using namespace std;

